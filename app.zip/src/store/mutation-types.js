export const USER_SIGNIN = 'USER_SIGNIN'    // 登录成功
export const USER_SIGNOUT = 'USER_SIGNOUT'  // 退出登录
