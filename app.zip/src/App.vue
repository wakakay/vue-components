<style lang="scss" scoped>
</style>
<template>
  <router-view></router-view>
</template>
<script>
  export default {

  }
</script>
