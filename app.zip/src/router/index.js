import App from '../app'

export default [
    {
        path: '/',
        component: App,
        children: [
            {
                path: '/login', // 登录
                component: resolve => require(['../pages/users/login.vue'], resolve)
            },
            {
                path: '/user-info', // 个人主页
                component: resolve => require(['../pages/users/user.vue'], resolve)
            },
            {
                path: '*',
                redirect: '/login'
            }
        ]
    }
]
