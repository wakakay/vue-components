<style lang="scss" scoped>
    @import '../assets/styles/scss/function.scss';
  
    .ui-cell-search{
        height:px2rem(78);padding:0 px2rem(35);font-size:px2rem(24);color:#1a1a1a;border-bottom:1px solid #edeff3;
      
        [class^='icon-'] {
            margin-right:px2rem(18);font-size:px2rem(24);color:#e8e8e8;
        }
    }
</style>

<template>
    <div class="ui-cell-search" flex="cross:center" @click="handleClick">
        <slot name="icon">
            <i v-if="icon" :class="'icon-' + icon"></i>
        </slot>
        <span v-text="title"></span>
    </div>
</template>

<script type="text/ecmascript-6">
    export default {
        name: 'cell-search',
        props: {
            icon: String,
            title: String
        },
    
        mounted() {
            // 如果有父组件，则将本身的属性传给父组件
            this.$parent && this.$parent.cellSearchCreated(this)
        },
    
        destroyed() {
            // 如果有父组件被销毁，该组件也跟着销毁
            this.$parent && this.$parent.cellSearchDestroyed(this)
        },
        
        methods: {
            handleClick (event) {
                this.$emit('click', event);
            }
        }
    }
</script>
