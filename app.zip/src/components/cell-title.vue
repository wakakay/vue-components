<style lang="scss" rel="stylesheet/scss" scoped>
    @import '../assets/styles/scss/function.scss';
    
    .ui-cell-title{
        height:px2rem(56);padding:0 px2rem(20) 0 px2rem(10);font-size:px2rem(28);color:#999;line-height:px2rem(56);border-bottom:2px solid #edeff3;
        [class^="icon-"]{
            display:block;width:px2rem(40);font-size:px2rem(26);
        }
        .ui-button{
            width:auto;height:px2rem(40);padding:0 px2rem(15);float:right;line-height:px2rem(40);
            .ui-button-icon{color:#999 !important;}
            [class^="icon-"]{font-size:px2rem(10);}
            &.ui-button-default{background:none;box-shadow:none;}
        }
    }
</style>

<template>
    <div class="ui-cell-title" flex="main:justify cross:center">
        <div flex="">
            <slot name="icon" flex-box="0">
                <i v-if="icon" :class="'icon-' + icon"></i>
            </slot>
            <span v-text="title" flex-box="1"></span>
        </div>
    
        <slot name="button"></slot>
    </div>
</template>

<script type="text/ecmascript-6">
    /**
     * v-slide
     * @module components/slide
     * @desc moren
     * @param {icon} [String] - 字体图标（不自动补全'icon-'）
     * @param {title} [String] - 文本文案
     *
     * @example
     * <v-title
     *   <v-cell-text></v-cell-text>
     * </v-title>
     */
    export default {
        name: 'cell-title',
        props: {
            icon: String,
            title: String
        },
        
        methods: {
        
        }
    }
</script>
